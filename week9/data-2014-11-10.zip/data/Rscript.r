# its a good idea in R to set the working directory
# to where your data files are stored: use the setwd command

setwd("C:\\student)
